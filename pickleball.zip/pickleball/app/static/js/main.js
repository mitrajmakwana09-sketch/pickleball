/* General Styles */

body {
    background-color: #f8f9fa;
    font-family: Arial, sans-serif;
}

/* Navbar */

.navbar-brand {
    font-weight: bold;
    font-size: 24px;
}

/* Cards */

.card {
    border: none;
    border-radius: 10px;
}

.card:hover {
    transform: translateY(-3px);
    transition: 0.3s;
}

/* Buttons */

.btn {
    border-radius: 8px;
}

/* Hero Section */

.hero-section {
    padding: 80px 0;
}

/* Court Images */

.card-img-top {
    height: 220px;
    object-fit: cover;
}

/* Footer */

footer {
    margin-top: 50px;
}

/* Dashboard Cards */

.dashboard-card {
    text-align: center;
    padding: 20px;
    border-radius: 10px;
}

/* Tables */

.table {
    background: white;
}

/* Responsive */

@media (max-width: 768px) {

    .hero-section {
        text-align: center;
    }

}