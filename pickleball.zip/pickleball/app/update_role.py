import sqlite3

# Connect to database
conn = sqlite3.connect("pickleball.db")
cursor = conn.cursor()

try:
    # Add role column
    cursor.execute("""
        ALTER TABLE users
        ADD COLUMN role TEXT DEFAULT 'customer'
    """)
    print("Role column added successfully!")

except sqlite3.OperationalError:
    print("Role column already exists.")

# Make first user admin
cursor.execute("""
    UPDATE users
    SET role = 'admin'
    WHERE id = 1
""")

conn.commit()

print("User ID 1 is now Admin.")

# Show all users
cursor.execute("""
    SELECT id, username, email, role
    FROM users
""")

users = cursor.fetchall()

print("\nUsers Table:")
for user in users:
    print(user)

conn.close()

print("\nDone!")