from functools import wraps
from datetime import datetime

from flask import render_template, request, redirect, url_for, flash, session, abort, make_response
from app import db
from app.models import User, Court, Booking, Payment, LogEntry
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
import os
from werkzeug.utils import secure_filename


SITE_LOGO_IMAGE = 'c53b6c07-ed47-4b4f-877f-371d79123b9e.jpg'


def _court_image_key(value):
    return ''.join(char.lower() for char in value if char.isalnum())


def _court_image_name(filename):
    return _court_image_key(os.path.splitext(filename)[0])


def _resolve_court_image(court, index, image_lookup, court_images):
    if court.image:
        stored_image = image_lookup.get(court.image.lower())
        if stored_image:
            return stored_image

    name_key = _court_image_key(court.name)
    for image_key in (name_key, f'court{index + 1}'):
        image = image_lookup.get(image_key)
        if image:
            return image

    if court_images:
        return court_images[index % len(court_images)]

    return None


def _court_card(court, image_filename):
    return {
        'id': court.id,
        'name': court.name,
        'location': court.location,
        'features': 'Parking, WiFi, Washroom',
        'price': court.price,
        'status': court.status,
        'image': image_filename,
        'view_url': url_for('court_detail', court_id=court.id),
        'booking_url': url_for('booking', court_id=court.id) if court.status == 'Available' else None,
    }


def _extra_court_defaults(number, image_filename):
    locations = [
        'Sports Complex, West Wing',
        'Sports Complex, East Wing',
        'Near Main Entrance',
        'Backyard Area',
        'Upper Floor',
        'North Side',
        'Premium Zone',
    ]
    features = [
        'Indoor, Parking, WiFi, Washroom',
        'Outdoor, Parking, WiFi',
        'Indoor, Parking, Washroom',
        'Outdoor, Parking, WiFi',
        'Indoor, Parking, WiFi, Washroom',
        'Outdoor, Parking',
        'Indoor, Parking, WiFi, Washroom, AC',
    ]

    return {
        'name': f'Court {number}',
        'location': locations[(number - 1) % len(locations)],
        'features': features[(number - 1) % len(features)],
        'price': 300 + ((number - 1) % 5) * 50,
        'status': 'Available',
        'image': image_filename,
    }


def _current_user():
    user_id = session.get('user_id')
    if not user_id:
        return None
    return User.query.get(user_id)


def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if not session.get('user_id'):
            flash('Please login first.', 'warning')
            return redirect(url_for('login', next=request.path))
        return view(*args, **kwargs)

    return wrapped_view


def admin_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if not session.get('user_id'):
            flash('Please login first.', 'warning')
            return redirect(url_for('login', next=request.path))

        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))

        return view(*args, **kwargs)

    return wrapped_view


def _payment_access_allowed(payment):
    if session.get('role') == 'admin':
        return True
    return payment.booking.user_id == session.get('user_id')


def init_routes(app):
    # Configure upload folder
    app.config['UPLOAD_FOLDER'] = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 
        'static', 'images', 'courts'
    )
    app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5MB
    
    # Ensure upload folder exists
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # Add no-cache headers to prevent browser from caching protected pages
    @app.after_request
    def add_no_cache_headers(response):
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '-1'
        return response

    @app.context_processor
    def inject_current_user():
        return {'current_user': _current_user()}

    # ----------------------
    # Home Page
    # ----------------------
    @app.route('/')
    def home():
        total_courts = Court.query.count()
        total_bookings = Booking.query.count()
        total_users = User.query.count()
        return render_template(
            'home.html',
            total_courts=total_courts,
            total_bookings=total_bookings,
            total_users=total_users
        )


    # ----------------------
    # Register
    # ----------------------
    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            confirm_password = request.form['confirm_password']
            
            # Check password match
            if password != confirm_password:
                flash('Passwords do not match!', 'danger')
                return redirect(url_for('register'))

            if User.query.filter_by(username=username).first():
                flash('Username already taken!', 'danger')
                return redirect(url_for('register'))

            if User.query.filter_by(email=email).first():
                flash('Email already registered!', 'danger')
                return redirect(url_for('register'))

            user = User(
                username=username,
                email=email,
                password=password
            )

            db.session.add(user)
            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()
                flash('Registration failed. Username or email may already be in use.', 'danger')
                return redirect(url_for('register'))

            flash('Registration Successful!', 'success')
            return redirect(url_for('login'))

        return render_template('register.html')


    # ----------------------
    # Admin Login
    # ----------------------
    @app.route('/admin/login', methods=['GET', 'POST'])
    def admin_login():
        if request.method == 'POST':
            email = request.form['email']
            password = request.form['password']

            user = User.query.filter_by(
                email=email,
                password=password
            ).first()

            if user and user.role == 'admin':
                session.clear()
                session['user_id'] = user.id
                session['username'] = user.username
                session['role'] = user.role
                flash('Admin Login Successful!', 'success')
                next_page = request.args.get('next')
                if next_page and next_page.startswith('/'):
                    return redirect(next_page)
                return redirect(url_for('admin_dashboard'))

            flash('Invalid admin credentials!', 'danger')

        return render_template('login.html', admin_login=True)


    # ----------------------
    # Admin Change Credentials
    # ----------------------
    @app.route('/admin/change-credentials', methods=['GET', 'POST'])
    def admin_change_credentials():
        if request.method == 'POST':
            current_email = request.form.get('current_email', '').strip()
            current_password = request.form.get('current_password', '').strip()
            new_email = request.form.get('new_email', '').strip()
            new_password = request.form.get('new_password', '').strip()
            confirm_password = request.form.get('confirm_password', '').strip()
            
            # Find user with current credentials
            user = User.query.filter_by(
                email=current_email,
                password=current_password
            ).first()
            
            if not user or user.role != 'admin':
                flash('Invalid email or password. Please check and try again.', 'danger')
                return redirect(url_for('admin_change_credentials'))
            
            # Update email if provided
            if new_email:
                if new_email == user.email:
                    flash('New email must be different from current email.', 'warning')
                    return redirect(url_for('admin_change_credentials'))
                
                if User.query.filter_by(email=new_email).first():
                    flash('Email already registered!', 'danger')
                    return redirect(url_for('admin_change_credentials'))
                
                user.email = new_email
                flash('Email updated successfully!', 'success')
            
            # Update password if provided
            if new_password:
                if not confirm_password:
                    flash('Please confirm the new password.', 'danger')
                    return redirect(url_for('admin_change_credentials'))
                
                if new_password != confirm_password:
                    flash('Passwords do not match!', 'danger')
                    return redirect(url_for('admin_change_credentials'))
                
                if len(new_password) < 4:
                    flash('Password must be at least 4 characters long.', 'danger')
                    return redirect(url_for('admin_change_credentials'))
                
                user.password = new_password
                flash('Password updated successfully!', 'success')
            
            try:
                db.session.commit()
                flash('Credentials updated successfully! Please login with your new credentials.', 'success')
                return redirect(url_for('admin_login'))
            except IntegrityError:
                db.session.rollback()
                flash('An error occurred while updating credentials.', 'danger')
            
            return redirect(url_for('admin_change_credentials'))
        
        return render_template('admin_change_credentials.html')


    # ----------------------
    # Login
    # ----------------------
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            email = request.form['email']
            password = request.form['password']

            user = User.query.filter_by(
                email=email,
                password=password
            ).first()

            if user:
                session.clear()
                session['user_id'] = user.id
                session['username'] = user.username
                session['role'] = user.role
                flash('Login Successful!', 'success')
                next_page = request.args.get('next')
                if next_page and next_page.startswith('/'):
                    return redirect(next_page)
                if user.role == 'admin':
                    return redirect(url_for('admin_dashboard'))
                return redirect(url_for('dashboard'))

            flash('Invalid Email or Password!', 'danger')

        return render_template('login.html', admin_login=False)


    # ----------------------
    # Logout
    # ----------------------
    @app.route('/logout')
    def logout():
        session.clear()
        flash('Logged out successfully.', 'success')
        return redirect(url_for('home'))


    # ----------------------
    # Dashboard
    # ----------------------
    @app.route('/dashboard')
    @login_required
    def dashboard():
        user = _current_user()
        if user.role == 'admin':
            return redirect(url_for('admin_dashboard'))

        total_courts = Court.query.count()
        total_bookings = Booking.query.filter_by(user_id=user.id, status='Booked').count()
        total_payments = (
            Payment.query
            .join(Booking)
            .filter(Booking.user_id == user.id, Payment.status == 'Paid')
            .distinct(Payment.booking_id)
            .count()
        )
        bookings = (
            Booking.query
            .filter_by(user_id=user.id, status='Booked')
            .order_by(Booking.created_at.desc())
            .limit(5)
            .all()
        )

        return render_template(
            'dashboard.html',
            total_courts=total_courts,
            total_bookings=total_bookings,
            total_payments=total_payments,
            bookings=bookings
        )


    # ----------------------
    # Courts
    # ----------------------
    @app.route('/courts')
    @login_required
    def courts():
        user = _current_user()
        if user.role == 'admin':
            return redirect(url_for('admin_courts'))

        courts = Court.query.all()
        court_images = []
        allowed_ext = ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg')

        try:
            for filename in os.listdir(app.config['UPLOAD_FOLDER']):
                if filename == SITE_LOGO_IMAGE:
                    continue
                if filename.lower().endswith(allowed_ext):
                    court_images.append(filename)
        except OSError:
            court_images = []

        court_images.sort()
        image_lookup = {}
        for filename in court_images:
            image_lookup[filename.lower()] = filename
            image_lookup[_court_image_name(filename)] = filename

        court_image_map = {
            court.id: _resolve_court_image(court, index, image_lookup, court_images)
            for index, court in enumerate(courts)
        }

        used_images = {
            image
            for image in court_image_map.values()
            if image
        }
        added_courts = False

        for filename in court_images:
            if filename not in used_images:
                defaults = _extra_court_defaults(Court.query.count() + 1, filename)
                court = Court(
                    name=defaults['name'],
                    location=defaults['location'],
                    price=defaults['price'],
                    status=defaults['status'],
                    image=defaults['image']
                )
                db.session.add(court)
                db.session.commit()
                added_courts = True
                used_images.add(filename)

        if added_courts:
            courts = Court.query.all()
            court_image_map = {
                court.id: _resolve_court_image(court, index, image_lookup, court_images)
                for index, court in enumerate(courts)
            }

        court_cards = [
            _court_card(court, court_image_map.get(court.id))
            for court in courts
        ]

        return render_template(
            'courts.html',
            courts=courts,
            court_images=court_images,
            court_image_map=court_image_map,
            court_cards=court_cards
        )


    # ----------------------
    # Court Details
    # ----------------------
    @app.route('/courts/<int:court_id>')
    @login_required
    def court_detail(court_id):
        user = _current_user()
        if user.role == 'admin':
            return redirect(url_for('admin_courts'))

        court = Court.query.get_or_404(court_id)
        court_images = []
        allowed_ext = ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg')

        try:
            for filename in os.listdir(app.config['UPLOAD_FOLDER']):
                if filename == SITE_LOGO_IMAGE:
                    continue
                if filename.lower().endswith(allowed_ext):
                    court_images.append(filename)
        except OSError:
            court_images = []

        court_images.sort()
        image_lookup = {}
        for filename in court_images:
            image_lookup[filename.lower()] = filename
            image_lookup[_court_image_name(filename)] = filename

        courts = Court.query.all()
        court_index = next(
            (index for index, existing_court in enumerate(courts) if existing_court.id == court.id),
            0
        )
        image_filename = _resolve_court_image(court, court_index, image_lookup, court_images)

        return render_template(
            'court_detail.html',
            court=court,
            image_filename=image_filename,
            features='Parking, WiFi, Washroom'
        )


    # ----------------------
    # Book Court
    # ----------------------
    @app.route('/booking/<int:court_id>', methods=['GET', 'POST'])
    @login_required
    def booking(court_id):
        from datetime import date, datetime, timedelta

        user = _current_user()
        if user.role == 'admin':
            flash('Admins cannot book courts from the user booking page.', 'warning')
            return redirect(url_for('admin_dashboard'))

        court = Court.query.get_or_404(court_id)

        if court.status != 'Available':
            flash('This court is not available for booking.', 'danger')
            return redirect(url_for('courts'))

        tomorrow = date.today() + timedelta(days=1)

        if request.method == 'POST':
            booking_date_str = request.form['booking_date']
            slot = request.form['slot']

            booking_date = datetime.strptime(booking_date_str, '%Y-%m-%d').date()

            if booking_date < tomorrow:
                flash('Please select tomorrow or a future date for booking.', 'danger')
                return render_template(
                    'booking.html',
                    court=court
                )

            # Check if slot is already booked
            existing_booking = Booking.query.filter_by(
                court_id=court.id,
                booking_date=booking_date,
                slot=slot,
                status='Booked'
            ).first()

            if existing_booking:
                flash('This slot is already booked! Please choose another time.', 'danger')
                return render_template(
                    'booking.html',
                    court=court
                )

            booking = Booking(
                user_id=user.id,
                court_id=court.id,
                booking_date=booking_date,
                slot=slot
            )

            db.session.add(booking)
            db.session.commit()

            # Log the booking
            log = LogEntry(action=f"Booked court {court.name} on {booking_date} at {slot}")
            db.session.add(log)
            db.session.commit()

            flash('Court booked successfully!', 'success')
            return redirect(url_for('my_bookings'))

        return render_template(
            'booking.html',
            court=court
        )


    # ----------------------
    # My Bookings
    # ----------------------
    @app.route('/my_bookings')
    @login_required
    def my_bookings():
        user = _current_user()
        if user.role == 'admin':
            return redirect(url_for('admin_bookings'))

        from datetime import datetime, timedelta
        today = datetime.now().date()

        bookings = (
            Booking.query
            .filter_by(user_id=user.id, status='Booked')
            .filter(Booking.booking_date >= today)
            .order_by(Booking.created_at.desc())
            .all()
        )
        return render_template('my_bookings.html', bookings=bookings)


    # ----------------------
    # Cancel Booking
    # ----------------------
    @app.route('/cancel_booking/<int:booking_id>')
    @login_required
    def cancel_user_booking(booking_id):
        booking = Booking.query.filter_by(
            id=booking_id,
            user_id=session['user_id']
        ).first_or_404()
        booking.status = 'Cancelled'
        
        # Also cancel any associated payment(s)
        payments = Payment.query.filter_by(booking_id=booking_id).all()
        for payment in payments:
            payment.status = 'Cancelled'
            payment.amount = 0
            if not payment.transaction_id:
                payment.transaction_id = f"TXN{booking.id}-CANCEL"
        
        db.session.commit()

        log = LogEntry(action=f"Cancelled booking {booking_id} for court {booking.court.name}")
        db.session.add(log)
        db.session.commit()

        flash('Booking cancelled successfully!', 'success')
        return redirect(url_for('my_bookings'))


    # ----------------------
    # Payment
    # ----------------------
    @app.route('/payment/<int:booking_id>', methods=['GET', 'POST'])
    @login_required
    def payment(booking_id):
        booking = Booking.query.filter_by(
            id=booking_id,
            user_id=session['user_id']
        ).first_or_404()

        if booking.status == 'Cancelled':
            cancelled_payment = Payment.query.filter_by(booking_id=booking.id).first()
            if cancelled_payment and cancelled_payment.status == 'Cancelled' and cancelled_payment.amount != 0:
                cancelled_payment.amount = 0
                db.session.commit()

            return render_template(
                'payment.html',
                booking=booking,
                payment_amount=0,
                booking_cancelled=True
            )

        paid_payment = Payment.query.filter_by(booking_id=booking.id, status='Paid').first()
        if paid_payment:
            return redirect(url_for('receipt', payment_id=paid_payment.id))

        if request.method == 'POST':
            payment = Payment.query.filter_by(booking_id=booking.id).first()

            if payment:
                payment.amount = booking.court.price
                payment.status = 'Paid'
                if not payment.transaction_id:
                    payment.transaction_id = f"TXN{booking.id}"
            else:
                payment = Payment(
                    booking_id=booking.id,
                    amount=booking.court.price,
                    status='Paid',
                    transaction_id=f"TXN{booking.id}"
                )
                db.session.add(payment)

            db.session.commit()

            flash('Payment Successful!', 'success')
            return redirect(url_for('receipt', payment_id=payment.id))

        return render_template('payment.html', booking=booking, payment_amount=booking.court.price)


    # ----------------------
    # Payment Receipt
    # ----------------------
    @app.route('/receipt/<int:payment_id>')
    @login_required
    def receipt(payment_id):
        payment = Payment.query.get_or_404(payment_id)
        if not _payment_access_allowed(payment):
            abort(403)

        return render_template('receipt.html', payment=payment)


    # ----------------------
    # Download Receipt
    # ----------------------
    @app.route('/receipt/<int:payment_id>/download')
    @login_required
    def download_receipt(payment_id):
        payment = Payment.query.get_or_404(payment_id)
        if not _payment_access_allowed(payment):
            abort(403)

        booking = payment.booking
        receipt_text = (
            "Pickleball Court Booking Receipt\n"
            "--------------------------------\n"
            f"Receipt ID: {payment.id}\n"
            f"Transaction ID: {payment.transaction_id}\n"
            f"Payment Status: {payment.status}\n"
            f"Payment Date: {payment.payment_date.strftime('%d-%m-%Y %H:%M')}\n"
            f"Customer: {booking.user.username}\n"
            f"Court: {booking.court.name}\n"
            f"Location: {booking.court.location}\n"
            f"Booking Date: {booking.booking_date}\n"
            f"Time Slot: {booking.slot}\n"
            f"Amount Paid: Rs. {payment.amount}\n"
        )
        response = make_response(receipt_text)
        response.headers['Content-Type'] = 'text/plain; charset=utf-8'
        response.headers['Content-Disposition'] = f'attachment; filename=receipt-{payment.id}.txt'
        return response


    # ----------------------
    # Admin Dashboard
    # ----------------------
    @app.route('/admin')
    @admin_required
    def admin_dashboard():
        logs = LogEntry.query.order_by(LogEntry.timestamp.desc()).limit(10).all()

        booked_bookings = Booking.query.filter_by(status='Booked')

        monthly_labels = []
        monthly_bookings = []
        now = datetime.utcnow()

        for offset in range(5, -1, -1):
            month_number = (now.month - offset - 1) % 12 + 1
            year_number = now.year + (now.month - offset - 1) // 12
            start_date = datetime(year_number, month_number, 1)

            if month_number == 12:
                next_year = year_number + 1
                next_month = 1
            else:
                next_year = year_number
                next_month = month_number + 1

            end_date = datetime(next_year, next_month, 1)
            count = booked_bookings.filter(
                Booking.booking_date >= start_date.date(),
                Booking.booking_date < end_date.date()
            ).count()

            monthly_labels.append(start_date.strftime('%b %Y'))
            monthly_bookings.append(count)

        top_court = (
            db.session.query(Court.name, func.count(Booking.id).label('booking_count'))
            .join(Booking)
            .filter(Booking.status == 'Booked')
            .group_by(Court.id, Court.name)
            .order_by(func.count(Booking.id).desc())
            .first()
        )

        top_hour = (
            db.session.query(Booking.slot, func.count(Booking.id).label('booking_count'))
            .filter(Booking.status == 'Booked')
            .group_by(Booking.slot)
            .order_by(func.count(Booking.id).desc())
            .first()
        )

        top_date = (
            db.session.query(Booking.booking_date, func.count(Booking.id).label('booking_count'))
            .filter(Booking.status == 'Booked')
            .group_by(Booking.booking_date)
            .order_by(func.count(Booking.id).desc())
            .first()
        )

        court_labels = []
        court_counts = []
        for court_stat in (
            db.session.query(Court.name, func.count(Booking.id).label('booking_count'))
            .join(Booking)
            .filter(Booking.status == 'Booked')
            .group_by(Court.id, Court.name)
            .order_by(func.count(Booking.id).desc())
            .limit(5)
            .all()
        ):
            court_labels.append(court_stat.name)
            court_counts.append(court_stat.booking_count)

        date_labels = []
        date_counts = []
        for date_stat in (
            db.session.query(Booking.booking_date, func.count(Booking.id).label('booking_count'))
            .filter(Booking.status == 'Booked')
            .group_by(Booking.booking_date)
            .order_by(func.count(Booking.id).desc())
            .limit(5)
            .all()
        ):
            date_labels.append(date_stat.booking_date.strftime('%d %b'))
            date_counts.append(date_stat.booking_count)

        return render_template(
            'admin/dashboard.html',
            users=User.query.count(),
            courts=Court.query.count(),
            bookings=Booking.query.count(),
            payments=Payment.query.count(),
            logs=logs,
            monthly_labels=monthly_labels,
            monthly_bookings=monthly_bookings,
            top_court_name=top_court.name if top_court else 'No bookings yet',
            top_court_count=top_court.booking_count if top_court else 0,
            top_hour_label=top_hour.slot if top_hour else 'No data',
            top_hour_count=top_hour.booking_count if top_hour else 0,
            top_date_label=top_date.booking_date.strftime('%d %b %Y') if top_date else 'No data',
            top_date_count=top_date.booking_count if top_date else 0,
            court_labels=court_labels,
            court_counts=court_counts,
            date_labels=date_labels,
            date_counts=date_counts,
        )


    # ----------------------
    # Admin Courts
    # ----------------------
    @app.route('/admin/courts')
    @admin_required
    def admin_courts():
        courts = Court.query.all()
        court_images = []
        allowed_ext = ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg')

        try:
            for filename in os.listdir(app.config['UPLOAD_FOLDER']):
                if filename.lower().endswith(allowed_ext):
                    court_images.append(filename)
        except OSError:
            court_images = []

        court_images.sort()
        image_lookup = {}
        for filename in court_images:
            image_lookup[filename.lower()] = filename
            image_lookup[_court_image_name(filename)] = filename

        court_image_map = {
            court.id: _resolve_court_image(court, index, image_lookup, court_images)
            for index, court in enumerate(courts)
        }

        return render_template(
            'admin/courts.html',
            courts=courts,
            court_image_map=court_image_map
        )


    # ----------------------
    # Add Court (Admin)
    # ----------------------
    @app.route('/admin/courts/add', methods=['GET', 'POST'])
    @admin_required
    def add_court():
        if request.method == 'POST':
            name = request.form['name']
            location = request.form['location']
            price = request.form['price']
            status = request.form['status']
            
            image_filename = None
            if 'image' in request.files:
                file = request.files['image']
                if file and file.filename:
                    filename = secure_filename(file.filename)
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    image_filename = filename

            court = Court(
                name=name,
                location=location,
                price=float(price),
                status=status,
                image=image_filename
            )

            db.session.add(court)
            db.session.commit()

            log = LogEntry(action=f"Added new court: {name}")
            db.session.add(log)
            db.session.commit()

            flash('Court added successfully!', 'success')
            return redirect(url_for('admin_courts'))

        return render_template('admin/add_court.html')


    # ----------------------
    # Edit Court (Admin)
    # ----------------------
    @app.route('/admin/courts/edit/<int:court_id>', methods=['GET', 'POST'])
    @admin_required
    def edit_court(court_id):
        court = Court.query.get_or_404(court_id)

        if request.method == 'POST':
            court.name = request.form['name']
            court.location = request.form['location']
            court.price = float(request.form['price'])
            court.status = request.form['status']
            
            if 'image' in request.files:
                file = request.files['image']
                if file and file.filename:
                    filename = secure_filename(file.filename)
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    court.image = filename

            db.session.commit()

            log = LogEntry(action=f"Updated court: {court.name}")
            db.session.add(log)
            db.session.commit()

            flash('Court updated successfully!', 'success')
            return redirect(url_for('admin_courts'))

        return render_template('admin/edit_court.html', court=court)


    # ----------------------
    # Delete Court (Admin)
    # ----------------------
    @app.route('/admin/courts/delete/<int:court_id>')
    @admin_required
    def delete_court(court_id):
        court = Court.query.get_or_404(court_id)
        court_name = court.name
        db.session.delete(court)
        db.session.commit()

        log = LogEntry(action=f"Deleted court: {court_name}")
        db.session.add(log)
        db.session.commit()

        flash('Court deleted successfully!', 'success')
        return redirect(url_for('admin_courts'))


    # ----------------------
    # Admin Bookings
    # ----------------------
    @app.route('/admin/bookings')
    @admin_required
    def admin_bookings():
        bookings = Booking.query.all()
        return render_template('admin/bookings.html', bookings=bookings)


    # ----------------------
    # Approve Booking (Admin)
    # ----------------------
    @app.route('/admin/bookings/approve/<int:booking_id>')
    @admin_required
    def approve_booking(booking_id):
        booking = Booking.query.get_or_404(booking_id)
        booking.status = 'Booked'
        db.session.commit()

        log = LogEntry(action=f"Approved booking {booking_id} for court {booking.court.name}")
        db.session.add(log)
        db.session.commit()

        flash('Booking approved successfully!', 'success')
        return redirect(url_for('admin_bookings'))


    # ----------------------
    # Cancel Booking (Admin)
    # ----------------------
    @app.route('/admin/bookings/cancel/<int:booking_id>')
    @admin_required
    def cancel_booking(booking_id):
        booking = Booking.query.get_or_404(booking_id)
        booking.status = 'Cancelled'
        
        # Also cancel any associated payment(s)
        payments = Payment.query.filter_by(booking_id=booking_id).all()
        for payment in payments:
            payment.status = 'Cancelled'
            payment.amount = 0
            if not payment.transaction_id:
                payment.transaction_id = f"TXN{booking.id}-CANCEL"
        
        db.session.commit()

        log = LogEntry(action=f"Cancelled booking {booking_id} for court {booking.court.name}")
        db.session.add(log)
        db.session.commit()

        flash('Booking cancelled successfully!', 'success')
        return redirect(url_for('admin_bookings'))


    # ----------------------
    # Delete Booking (Admin)
    # ----------------------
    @app.route('/admin/bookings/delete/<int:booking_id>')
    @admin_required
    def delete_booking(booking_id):
        booking = Booking.query.get_or_404(booking_id)
        db.session.delete(booking)
        db.session.commit()

        log = LogEntry(action=f"Deleted booking {booking_id}")
        db.session.add(log)
        db.session.commit()

        flash('Booking deleted successfully!', 'success')
        return redirect(url_for('admin_bookings'))


    # ----------------------
    # Admin Users
    # ----------------------
    @app.route('/admin/users')
    @admin_required
    def admin_users():
        users = User.query.all()
        return render_template('admin/users.html', users=users)


    # ----------------------
    # Delete User (Admin)
    # ----------------------
    @app.route('/admin/users/delete/<int:user_id>')
    @admin_required
    def delete_user(user_id):
        user = User.query.get_or_404(user_id)

        if user.role == 'admin' and User.query.filter_by(role='admin').count() == 1:
            flash('Cannot delete the only admin user.', 'danger')
            return redirect(url_for('admin_users'))

        username = user.username
        db.session.delete(user)
        db.session.commit()

        log = LogEntry(action=f"Deleted user: {username}")
        db.session.add(log)
        db.session.commit()

        flash('User deleted successfully!', 'success')
        return redirect(url_for('admin_users'))


    # ----------------------
    # Admin Payments
    # ----------------------
    @app.route('/admin/payments')
    @admin_required
    def admin_payments():
        payments = Payment.query.all()
        return render_template('admin/payments.html', payments=payments)


    # ----------------------
    # Admin Logs
    # ----------------------
    @app.route('/admin/logs')
    @admin_required
    def admin_logs():
        logs = LogEntry.query.order_by(LogEntry.timestamp.desc()).all()
        return render_template('admin/log_entery.html', logs=logs)


    # ----------------------
    # Admin Settings
    # ----------------------
    @app.route('/admin/settings', methods=['GET', 'POST'])
    @admin_required
    def admin_settings():
        user = _current_user()
        
        if request.method == 'POST':
            current_password = request.form.get('current_password', '').strip()
            new_email = request.form.get('new_email', '').strip()
            new_password = request.form.get('new_password', '').strip()
            confirm_password = request.form.get('confirm_password', '').strip()
            
            # Validate current password
            if not current_password:
                flash('Current password is required.', 'danger')
                return redirect(url_for('admin_settings'))
            
            if user.password != current_password:
                flash('Current password is incorrect.', 'danger')
                return redirect(url_for('admin_settings'))
            
            # Update email if provided
            if new_email:
                if new_email == user.email:
                    flash('New email must be different from current email.', 'warning')
                    return redirect(url_for('admin_settings'))
                
                if User.query.filter_by(email=new_email).first():
                    flash('Email already registered!', 'danger')
                    return redirect(url_for('admin_settings'))
                
                user.email = new_email
                flash('Email updated successfully!', 'success')
            
            # Update password if provided
            if new_password:
                if not confirm_password:
                    flash('Please confirm the new password.', 'danger')
                    return redirect(url_for('admin_settings'))
                
                if new_password != confirm_password:
                    flash('Passwords do not match!', 'danger')
                    return redirect(url_for('admin_settings'))
                
                if len(new_password) < 4:
                    flash('Password must be at least 4 characters long.', 'danger')
                    return redirect(url_for('admin_settings'))
                
                user.password = new_password
                flash('Password updated successfully!', 'success')
            
            try:
                db.session.commit()
                flash('Settings updated successfully!', 'success')
            except IntegrityError:
                db.session.rollback()
                flash('An error occurred while updating settings.', 'danger')
            
            return redirect(url_for('admin_settings'))
        
        return render_template('admin/settings.html', user=user)
