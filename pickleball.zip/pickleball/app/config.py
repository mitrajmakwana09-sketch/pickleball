import os

# Base directory of the project
BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
os.makedirs(INSTANCE_DIR, exist_ok=True)

class Config:
    # Secret key for sessions and security
    SECRET_KEY = "pickleball_secret_key_123"

    # SQLite Database Configuration
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(INSTANCE_DIR, "pickleball.db")

    # Disable modification tracking (improves performance)
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Upload Folder for Court Images
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "images", "courts")

    # Maximum Upload Size (5 MB)
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024

    # Allowed Image Extensions
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}
