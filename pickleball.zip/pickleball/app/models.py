from app import db
from datetime import datetime



# ----------------------
# User Model
# ----------------------
class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(
        db.String(100),
        unique=True,
        nullable=False
    )

    email = db.Column(
        db.String(120),
        unique=True,
        nullable=False
    )

    password = db.Column(
        db.String(255),
        nullable=False
    )

    # admin or customer
    role = db.Column(
        db.String(20),
        nullable=False,
        default="customer"
    )

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    bookings = db.relationship(
        "Booking",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<User {self.username}>"


# ----------------------
# Court Model
# ----------------------
class Court(db.Model):
    __tablename__ = "courts"

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    name = db.Column(
        db.String(100),
        nullable=False
    )

    location = db.Column(
        db.String(200),
        nullable=False
    )

    price = db.Column(
        db.Float,
        nullable=False
    )

    image = db.Column(
        db.String(255)
    )

    status = db.Column(
        db.String(20),
        default="Available"
    )

    bookings = db.relationship(
        "Booking",
        backref="court",
        lazy=True
    )

    def __repr__(self):
        return f"<Court {self.name}>"


# ----------------------
# Booking Model
# ----------------------
class Booking(db.Model):
    __tablename__ = "bookings"

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    user_id = db.Column(
        db.Integer,
        db.ForeignKey("users.id"),
        nullable=False
    )

    court_id = db.Column(
        db.Integer,
        db.ForeignKey("courts.id"),
        nullable=False
    )

    booking_date = db.Column(
        db.Date,
        nullable=False
    )

    slot = db.Column(
        db.String(50),
        nullable=False
    )

    status = db.Column(
        db.String(20),
        default="Booked"
    )

    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    payment = db.relationship(
        "Payment",
        backref="booking",
        uselist=False,
        cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<Booking {self.id}>"


# ----------------------
# Payment Model
# ----------------------
class Payment(db.Model):
    __tablename__ = "payments"

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    booking_id = db.Column(
        db.Integer,
        db.ForeignKey("bookings.id"),
        nullable=False
    )

    amount = db.Column(
        db.Float,
        nullable=False
    )

    status = db.Column(
        db.String(20),
        default="Pending"
    )

    transaction_id = db.Column(
        db.String(100),
        unique=True
    )

    payment_date = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    def __repr__(self):
        return f"<Payment {self.id}>"


# ----------------------
# Log Entry Model
# ----------------------
class LogEntry(db.Model):
    __tablename__ = "logs"

    id = db.Column(
        db.Integer,
        primary_key=True
    )

    action = db.Column(
        db.String(255),
        nullable=False
    )

    timestamp = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )

    def __repr__(self):
        return f"<Log {self.action}>"

