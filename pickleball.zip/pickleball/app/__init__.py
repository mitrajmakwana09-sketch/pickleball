from flask import Flask  # type: ignore[import]
from flask_sqlalchemy import SQLAlchemy  # type: ignore[import]
from app.config import Config

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)

    app.config.from_object(Config)

    db.init_app(app)

    with app.app_context():
        from app.models import User, Court, Booking, Payment, LogEntry
        db.create_all()
    
    # Import and register routes
    from app import routes
    routes.init_routes(app)

    return app
